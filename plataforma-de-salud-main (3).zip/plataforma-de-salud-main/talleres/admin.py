from django.contrib import admin
from talleres.models import Taller
from import_export.admin import ImportExportModelAdmin

# class TallerAdmin(ImportExportModelAdmin):
    # readonly_fields = ('fecha_hora',"estado")
    # list_display = ('fecha_hora', 'numero_clave', 'nombre', 'documentacion', 'sexo', 'edad', 'estado', 'localidad','municipio', 'telefono', 'seguridad_social', 'quimica_sanguinea', 'biometria', 'orina', 'ultrasonido_obstetrico', 'ultrasonido_pelvico', 'ultrasonido_mamario', 'entrevista_medica_dental', 'papanicolau', 'prueba_vph', 'prueba_vih', 'prueba_antigeno_prostatico', 'consulta_dental', 'extraccion_dental_simple', 'aplicacion_de_fluor', 'entrevista_medica_rx', 'rx_abdomen', 'rx_torax', 'rx_pierna', 'rx_brazo', 'rx_mano', 'eletrocardiograma')
    # search_fields = ('numero_clave',)
    # list_display_links = ('nombre', 'numero_clave',)
    # list_per_page = 50
    # list_filter = ('edad', 'municipio', 'localidad', )

    # fieldsets = (
    #    ('INFORMACIÓN PERSONAL', {
    #        'fields': ('fecha_hora','nombre', 'documentacion', 'numero_clave', 'seguridad_social','sexo', 'edad')
    #    }),
    #    ('INFORMACIÓN DE CONTACTO', {
    #        'fields': ('estado', 'municipio', "localidad", 'telefono')
    #    }),
    #    ('UM. LABORATORIOS Y ULTRASONIDO', {
    #        'fields': ('quimica_sanguinea', 'biometria','orina','ultrasonido_obstetrico', 'ultrasonido_pelvico', 'ultrasonido_mamario')
    #    }),
    #    ('UM. MÉDICO DENTAL', {
    #        'fields': ('entrevista_medica_dental', 'papanicolau', 'prueba_vph', 'prueba_vih', 'prueba_antigeno_prostatico', 'consulta_dental', 'extraccion_dental_simple', 'aplicacion_de_fluor',)
    #    }),
    #    ('UM. ENTREVISTA E IMAGEN', {
    #        'fields': ('entrevista_medica_rx', 'rx_abdomen', 'rx_torax', 'rx_pierna', 'rx_brazo', 'rx_mano', 'eletrocardiograma')
    #        }))


admin.site.register(Taller)
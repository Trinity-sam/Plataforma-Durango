from django.db import models

class Taller(models.Model):
    atividade = models.CharField(default='', max_length=100)

    def __str__(self):
        return self.atividade

    class Meta:
        verbose_name_plural = 'Registro y controles de talleres'

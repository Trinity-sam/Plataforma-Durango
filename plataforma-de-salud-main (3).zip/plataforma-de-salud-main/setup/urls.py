from django.contrib import admin
from django.urls import path

admin.site.index_title = 'Andy'

urlpatterns = [
    path('', admin.site.urls),
]

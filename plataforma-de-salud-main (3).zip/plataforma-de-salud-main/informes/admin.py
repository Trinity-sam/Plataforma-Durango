from django.contrib import admin
from informes.models import Informe
from import_export.admin import ExportActionMixin
from django.contrib.admin import DateFieldListFilter

@admin.register(Informe)
class InformeAdmin(ExportActionMixin, admin.ModelAdmin):
    list_display = ('total_0_2', 'total_3_7', 'total_8_15', 'total_16_25', 'total_26_40', 'total_41_60', 'total_61_adelante', 'total_personas',)
    readonly_fields = ( 'fecha_hora', 'total_0_2', 'total_3_7', 'total_8_15', 'total_16_25', 'total_26_40', 'total_41_60', 'total_61_adelante', 'total_personas',)
    list_filter = (
        ('fecha_hora', DateFieldListFilter),
    )
    def has_delete_permission(self, request, obj=None):
        return False
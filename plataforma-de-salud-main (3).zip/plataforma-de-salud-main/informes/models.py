from django.db import models
from pacientes.models import Paciente
from django.utils import timezone

class Informe(models.Model):
    fecha_hora = models.DateTimeField(verbose_name="Fecha y Hora", default=timezone.now)
    total_0_2 = models.IntegerField(default=0)
    total_3_7 = models.IntegerField(default=0)
    total_8_15 = models.IntegerField(default=0)
    total_16_25 = models.IntegerField(default=0)
    total_26_40 = models.IntegerField(default=0)
    total_41_60 = models.IntegerField(default=0)
    total_61_adelante = models.IntegerField(default=0)
    total_personas = models.IntegerField(default=0)

    class Meta:
        verbose_name_plural = 'Informes de pacientes'

    def __str__(self):
        return f'Informe #{self.pk} - {self.fecha_hora.strftime("%d/%m/%Y")}'

    def atualizar_informe(self):
        # realiza a agregação das informações do modelo Paciente
        self.total_0_2 = Paciente.objects.filter(edad='1').count()
        self.total_3_7 = Paciente.objects.filter(edad='2').count()
        self.total_8_15 = Paciente.objects.filter(edad='3').count()
        self.total_16_25 = Paciente.objects.filter(edad='4').count()
        self.total_26_40 = Paciente.objects.filter(edad='5').count()
        self.total_41_60 = Paciente.objects.filter(edad='6').count()
        self.total_61_adelante = Paciente.objects.filter(edad='7').count()
        self.total_personas = self.total_0_2 + self.total_3_7 + self.total_8_15 + self.total_16_25 + self.total_26_40 + self.total_41_60 + self.total_61_adelante

        
    def save(self, *args, **kwargs):
        self.atualizar_informe()
        super().save(*args, **kwargs)
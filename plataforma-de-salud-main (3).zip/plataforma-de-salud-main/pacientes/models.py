from django.db import models
from django.core.validators import RegexValidator
from django.utils import timezone

# Este es un modelo de datos para la clase Paciente en Django. Define la información que puede almacenarse para un paciente, incluyendo su nombre, tipo de documento de identificación, número de identificación, género, edad, estado y municipio de residencia, número de teléfono e información de seguridad social. También incluye información sobre los exámenes médicos y dentales realizados por el paciente, incluyendo exámenes de sangre, ecografías, radiografías, pruebas de diagnóstico y consultas dentales.

# Algunas informaciones sobre el modelo:

# Hay tres opciones de tipos de documentos de identificación: INE, CURP y una opción predeterminada para INE.
# Hay cinco opciones para el género: masculino, femenino, no binario, prefiero no informar y otro.
# Hay siete opciones para la edad: 0-2, 3-7, 8-15, 16-25, 26-40, 41-60 y 61 años o más.
# Hay dos opciones para el municipio: Canatlán y Ceballos.
# Hay seis opciones para la seguridad social: IMSS, ISSSTE, Insabi, Pemex, Sedena y otro.
# Hay varias opciones para los exámenes médicos y dentales realizados por el paciente, incluyendo exámenes de sangre, ecografías, radiografías, pruebas de diagnóstico y consultas dentales. Cada opción está representada por un booleano que indica si se realizó o no el examen.
# La función __str__ devuelve el número de identificación del paciente, que es el identificador único del paciente en la base de datos.
# El ordering especifica que los pacientes deben ser ordenados en orden descendente por id.

class Paciente(models.Model):
    TIPO_DE_DOCUMENTACION = (
        ('I', 'INE'),
        ('C', 'CURP')
    )
    TIPO_SEXO = (
        ('1', 'Masculino'),
        ('2', 'Femenino'),
        ('3', 'No-binário'),
        ('4', 'Prefiero no informar'),
        ('5', 'Otro')
    )
    EDAD_FILTRO = (
        ('1', '0-2'),
        ('2', '3-7'),
        ('3', '8-15'),
        ('4', '16-25'),
        ('5', '26-40'),
        ('6', '41-60'),
        ('7', '61 en adelante')
    )
    MUNICIPIOS_LISTA = (
        ('Canatlan', 'Canatlan'),
        ('Canelas', 'Canelas'),
        ('Coneto de Comonfort', 'Coneto de Comonfort'),
        ('Cuencame', 'Cuencame'),
        ('Durango', 'Durango'),
        ('El Oro', 'El Oro'),
        ('General Simon Bolivar', 'General Simon Bolivar'),
        ('Gomez Palacio', 'Gomez Palacio'),
        ('Guadalupe Victoria', 'Guadalupe Victoria'),
        ('Guanacevi', 'Guanacevi'),
        ('Hidalgo', 'Hidalgo'),
        ('Inde', 'Inde'),
        ('Lerdo', 'Lerdo'),
        ('Mapimi', 'Mapimi'),
        ('Mezquital', 'Mezquital'),
        ('Nazas', 'Nazas'),
        ('Nombre de Dios', 'Nombre de Dios'),
        ('Nuevo Ideal', 'Nuevo Ideal'),
        ('Ocampo', 'Ocampo'),
        ('Otaez', 'Otaez'),
        ('Panuco de Coronado', 'Panuco de Coronado'),
        ('Penon Blanco', 'Penon Blanco'),
        ('Poanas', 'Poanas'),
        ('Pueblo Nuevo', 'Pueblo Nuevo'),
        ('Rodeo', 'Rodeo'),
        ('San Bernardo', 'San Bernardo'),
        ('San Dimas', 'San Dimas'),
        ('San Juan de Guadalupe', 'San Juan de Guadalupe'),
        ('San Juan del Rio', 'San Juan del Rio'),
        ('San Luis del Cordero', 'San Luis del Cordero'),
        ('San Pedro del Gallo', 'San Pedro del Gallo'),
        ('Santa Clara', 'Santa Clara'),
        ('Santiago Papasquiaro', 'Santiago Papasquiaro'),
        ('Suchil', 'Suchil'),
        ('Tamazula', 'Tamazula'),
        ('Tepehuanes', 'Tepehuanes'),
        ('Tlahualilo', 'Tlahualilo'),
        ('Topia', 'Topia'),
        ('Vicente Guerrero', 'Vicente Guerrero'),
    )
    seguro_social = (
        ('IMSS', 'IMSS'),
        ('ISSSTE', 'ISSSTE'),
        ('Insabi','Insabi'),
        ('Pemex', 'Pemex'), 
        ('Sedena', 'Sedena'),
        ('Otro', 'Otro')
    )
    
    fecha_hora = models.DateTimeField(verbose_name="Fecha y Hora", default=timezone.now)
    nombre = models.CharField(max_length=250)
    documentacion = models.CharField(max_length=1, choices=TIPO_DE_DOCUMENTACION, blank=False, null=False, default='INE')
    numero_clave = models.CharField(max_length=20, default='')
    sexo = models.CharField(max_length=1, choices=TIPO_SEXO, blank=False, null=False, default='2')
    edad = models.CharField(max_length=1, choices=EDAD_FILTRO, blank=False, null=False, default='1')
    estado = models.CharField(max_length=7, default="Durango")
    municipio = models.CharField(max_length=50, choices=MUNICIPIOS_LISTA, blank=False, null=False, default='Ciudad Durango')
    localidad = models.CharField(max_length=50, default='')
    telefono = models.CharField(max_length=20, validators=[RegexValidator(r'^\d+$', 'Solamente numeros son permitidos')])
    seguridad_social = models.CharField(max_length=50, choices=seguro_social, default='IMSS')
    quimica_sanguinea = models.BooleanField(default=False, verbose_name="Química Sanguínea")
    biometria = models.BooleanField(default=False, verbose_name="Biometría hemática")
    orina = models.BooleanField(default=False, verbose_name="Examen General de Orina")
    ultrasonido_obstetrico = models.BooleanField(default=False, verbose_name="Ultrasonido obstétrico")
    ultrasonido_pelvico = models.BooleanField(default=False, verbose_name="Ultrasonido Pélvico")
    ultrasonido_mamario = models.BooleanField(default=False, verbose_name="Ultrasonido Mamario")
    entrevista_medica_dental = models.BooleanField(default=False, verbose_name="Entrevista médica, somatometría y toma de signos vitales")
    papanicolau = models.BooleanField(default=False, verbose_name="Elaboración e interpretación de Papanicolau")
    prueba_vph = models.BooleanField(default=False, verbose_name="Prueba de VPH (PCR)")
    prueba_vih = models.BooleanField(default=False, verbose_name="Prueba rápida de VIH")
    prueba_antigeno_prostatico = models.BooleanField(default=False, verbose_name="Prueba rápida de Antígeno prostático")
    consulta_dental = models.BooleanField(default=False, verbose_name="Consulta dental")
    extraccion_dental_simple = models.BooleanField(default=False, verbose_name="Extracción dental simple")
    aplicacion_de_fluor = models.BooleanField(default=False, verbose_name="Aplicación de flúor")
    entrevista_medica_rx = models.BooleanField(default=False, verbose_name="Entrevista médica (raio x), somatometría y toma de signos vitales")
    rx_abdomen = models.BooleanField(default=False, verbose_name="Rx Abdomen")
    rx_torax = models.BooleanField(default=False, verbose_name="Rx Tórax")
    rx_pierna = models.BooleanField(default=False, verbose_name="Rx Pierna")
    rx_brazo = models.BooleanField(default=False, verbose_name="Rx Brazo")
    rx_mano = models.BooleanField(default=False, verbose_name="Rx Mano")
    eletrocardiograma = models.BooleanField(default=False, verbose_name="Eletrocardiograma")

    def __str__(self):
        return self.numero_clave
    
    class Meta:
        ordering = ["-id"]

    class Meta:
        verbose_name_plural = 'Registro y controles de pacientes'
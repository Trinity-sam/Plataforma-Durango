# Hey Andy

Siga os passos abaixo para executar este programa:

- crie um ambiente virtual e instale as dependências do projeto

```python3 -m venv ./venv```

- ative o ambiente virtual

```source venv/bin/activate```

- instale as dependências

```pip install -r requirements.txt```

- suba as migrações para criar o banco de dados

```python manage.py migrate```

- crie um superuser (cadastre apenas nome e senha do admin)

```python manage.py createsuperuser```

- rode o projeto

```python manage.py runserver```

- acesse a página 

http://localhost:8000/admin/



# Acessando o projeto com Docker

Faça o download do projeto

Abre o projeto no VSCODE e no terminal (comand j) vc digita:

```
docker-compose build
```

Para subir o projeto e ver tudo funcionando 

```
docker-compose up
```